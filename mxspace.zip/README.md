# 嘿，这里是 Mix Space 👋

<img src="https://cdn.jsdelivr.net/gh/mx-space/.github@main/uwu.png" />

Mix Space 是一个个人空间，也可以用作个人博客，功能更全面，并且持续更新。

[在线预览](https://innei.in)

我们有两个核心仓库。

- [core](https://github.com/mx-space/mx-server)：Mix Space 的核心服务，提供 RESTful API、定时任务、备份、无服务器函数等功能。
- [mx-admin](https://github.com/mx-space/mx-admin)：Mix Space 服务器的管理后台，风格简洁，功能全面。

目前，我们有三种前端风格。

- [Shiro](https://github.com/Innei/Shiro)：极简的个人网站，体现纸张的纯净和雪的新鲜。
- [kami](https://github.com/mx-space/kami)：Mix Space 的 Web 前端风格，可爱又迷人，完全支持 mx-server。
- [mx-web-yun](https://github.com/mx-space/mx-web-yun)：☁️ 为 Mix Space 设计的快速、轻量、可爱的主题。一个对可爱自以为是的前端风格。

我们还有生态系统。

- [docker](https://github.com/mx-space/docker)：一个 docker-compose 文件，用于快速部署 mx-space 系统，非常酷。
- [api-client](https://github.com/mx-space/core/blob/master/packages/api-client)：为 mx-space RESTful API 提供的 HTTP 客户端，用于快速构建新的前端项目。
- [imx-bot](https://github.com/Innei/imx-bot)：带有 mx-space 事件处理器的 QQ 机器人。
- [mx-tg-bot](https://github.com/mx-space/mx-tg-bot)：为 Mix Space 提供的 Telegram 机器人。
- [ProcessReporterMac](https://github.com/mx-space/ProcessReporterMac)：一个 macOS 应用程序，用于实时报告前台应用程序的名称和正在播放的媒体信息。
  - [Processforlinux](https://github.com/ttimochan/processforlinux)：适用于 Linux 用户。
  - [ProcessReporterWinpy](https://github.com/TNXG/ProcessReporterWinpy)、[ProcessReporterWin](https://github.com/ChingCdesu/ProcessReporterWin)、[WinProcessReporter](https://github.com/rdp-studio/WinProcessReporter)：适用于 Windows 用户。

文档已就绪。[前往](https://github.com/mx-space/docs)。

---

此 uwu 标志由 [Arthals](https://github.com/zhuozhiyongde) 创作，保留所有权利。